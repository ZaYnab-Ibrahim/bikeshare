# -*- coding: utf-8 -*-
"""
Created on Wed Apr 21 14:41:05 2021

@author: DELL
"""

import time
import pandas as pd
import numpy as np

    
CITY_DATA = { 1 : 'chicago.csv',
              2 : 'new_york_city.csv',
             3 : 'washington.csv' }               

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # TO DO: get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    while True:
        try:
            city = int(input( "kindly Select a city number  \n\'Enter 1 for chicago, 2 for new york, 3 for washington\' \n Enter a number:"))
            if city not in range(1,4):
                print('please enter an correct number')
            else:
                break
        except:
            print('please select a city number')


    # TO DO: get user input for month (all, january, february, ... , june)
    while True:
        try:
            month = int(input("kindly select a month number \n\'select a month from january=1 to june=6 or to type \'0\' to  display all months\' \n Enter a month number = "))
            if month not in range(0,7):
                print('please select an correct number')
            else:
                break
        except:
            print('please select a month number')


    # TO DO: get user input for day of week (all, monday, tuesday, ... sunday)
    while True:
        try:
            day = int(input("kindly select a day number \n\'select a day from monday=0 to sunday=6 or to type \'7\' to  display all days\' \n Enter a day number = "))
            if day not in range(0,8):
                print('please select an correct number')
            else:
                break
        except:
            print('please select a day number')


    print('-'*40)
    return city, month, day

def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    df= pd.read_csv(CITY_DATA[city])
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['month'] = df['Start Time'].dt.month
    df['day_of_week']= df['Start Time'].dt.dayofweek
    if month != 0:
        df = df[df['month'] == month]
    if day != 7:
        df = df[df['day_of_week'] == day]
    return df
       
def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    print('most common month:', df['month'].mode()[0])

    # display the most common day of week
    print('most common day:', df['day_of_week'].mode()[0])

    # display the most common start hour
    df['hour'] = df['Start Time'].dt.hour
    print('most common start hour:', df['hour'].mode()[0])


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    
def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    print('most used start station:', df['Start Station'].mode()[0])

    # display most commonly used end station
    print('most used end station:', df['End Station'].mode()[0])

    # display most frequent combination of start station and end station trip
    most_start_end = (df['Start Station'] + ' to ' + df['End Station']).mode()[0]
    print('most_start_end:' , most_start_end )


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


    return df

def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    print('total travel time:', df['Trip Duration'].sum())

    # display mean travel time
    print('mean travel time:', df['Trip Duration'].mean())


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    print('counts of user type:', df['User Type'].value_counts())


    # Display counts of gender
    if 'Gender' in df:
        print('counts of gender:', df['Gender'].value_counts())

    # Display earliest, most recent, and most common year of birth
    if 'Birth Year' in df:
        earliest = df['Birth Year'].min()
        most_recent = df['Birth Year'].max()
        common_year =  df['Birth Year'].mode()[0]
        print('earliest{}, most recent{}, most commn year of birth{}'.format(earliest, most_recent, common_year))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def display_raw_data(df):
    print('\n Raw data is available to check... \n')
    i = 0
    display_raw = int(input( 'May you want to have a look on the first 5 rows of data? Type 1 for \'yes\' or 0 for \'no\' \n Enter number:'))
    while True:
        if display_raw == 0:
            break
        print(df[i:i+5])
        display_raw = int(input( 'May you want to have a look on the next 5 row of data? Type 1 for \'yes\' or 0 for \'no\' \n Enter number:'))
        i += 5

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        
        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        display_raw_data(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break

if __name__ == "__main__":
	main()
